<!doctype html>
<html lang="pt-br" class="device-c traffic-source-g">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimal-ui">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta name="google" content="notranslate">
                <title>Fatura Hipercard</title>                    <meta name="description" content="Info sobre solicitar cartao Hipercard. Resultados de 8 Motores de Busca!">
<script>
            var appBrand = {"name":"iZito","slug":"izito"};
            var appMenu = [{"id":"default_search","text":"Web","url":"\/?locale=pt_BR&q=solicitar%20cartao%20Hipercard&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H&mdc=y","active":true},{"id":"image","text":"Imagens","url":"\/image?locale=pt_BR&q=solicitar%20cartao%20Hipercard&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H&mdc=y","active":false},{"id":"video","text":"V\u00eddeo","url":"\/video?locale=pt_BR&q=solicitar%20cartao%20Hipercard&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H&mdc=y","active":false},{"id":"news","text":"Not\u00edcia","url":"\/news?locale=pt_BR&q=solicitar%20cartao%20Hipercard&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H&mdc=y","active":false},{"id":"advanced_search","text":"Avan\u00e7ada","url":"\/adv\/?locale=pt_BR&q=solicitar%20cartao%20Hipercard&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H","active":false},{"id":"preferences","text":"Suas configura\u00e7\u00f5es de busca","url":"\/pref\/?locale=pt_BR&q=solicitar%20cartao%20Hipercard&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H","active":false}];
            var appPersistentPathQueryString = 'locale=pt_BR&q=solicitar+cartao+Hipercard&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H';
            var appPersistentPathQueryStringWithoutQuery = 'locale=pt_BR&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H';
            var appReady = [];
            var appSettings = {
                errorLogEnabled: true,
                statisticsEnabled: true
            };
            var appVariant = null;
            var appTime = 1647005921;
        </script>
        <script>"use strict";function persistentPath(e){return e+(0<=e.indexOf("?")?"&":"?")+appPersistentPathQueryString}function persistentPathWithoutQuery(e){return e+(0<=e.indexOf("?")?"&":"?")+appPersistentPathQueryStringWithoutQuery}function logError(e){appSettings.errorLogEnabled&&appReady.push(function(){(new Image).src=persistentPath("/js-error?error="+encodeURIComponent(e)+"&url="+encodeURIComponent(window.location.href))}),window.console&&window.console.error&&window.console.error(e)}</script>
<script>"use strict";function DelayedContainer(){return{_show:!1,_showDelayedElementCallback:null,_loadTime:(new Date).getTime(),getLoadTime:function(){return this._loadTime},isShow:function(){return this._show},forceShow:function(){this._show=!0},enableShowDelayedContentTimer:function(){var e=this;this._show?this.showDelayedContent():setTimeout(function(){e.showDelayedContent()},2500)},showDelayedContent:function(){this._show=!0;for(var e=1;e<=20;e++){var t=document.getElementById("delayed-container-"+e);if(null===t)break;t.style.visibility="visible",this._handleShowDelayedElementCallback(t)}},_handleShowDelayedElementCallback:function(e){null!==this._showDelayedElementCallback&&this._showDelayedElementCallback(e)},showSearchResultsTitle:function(){var e=document.getElementById("search-results-title-container");null!==e&&(e.style.display="block")},showFallbackContent:function(){var t=this;Helper.iterateHtmlElements(".search-container__csa",function(e){ClassList.has(e,"search-container__csa--loaded")||t.showFallbackContentElement(e,!0)})},showFallbackContentElement:function(e,t){Helper.iterateHtmlElements(".fallback-"+e.id,function(e){ClassList.toggle(e,"search-container__results-inner--hidden",!t),ClassList.toggle(e,"component--hidden",!t)})},setShowDelayedElementCallback:function(e){this._showDelayedElementCallback=e}}}var delayedContainer;try{(delayedContainer=new DelayedContainer).enableShowDelayedContentTimer()}catch(e){logError(e)}</script>
<!--[if lt IE 11]>
<script>
    delayedContainer.forceShow();
</script>
<![endif]-->
<script type="text/javascript" charset="utf-8">
    (function(g,o){g[o]=g[o]||function(){(g[o]['q']=g[o]['q']||[]).push(
        arguments)},g[o]['t']=1*new Date})(window,'_googCsa');
</script>

<script>"use strict";function GoogleAds(){return{_adsScriptLoaded:!1,_adsAmount:!1,_adsLoadTime:(new Date).getTime(),create:function(){var t=this;return appReady.push(function(){setTimeout(function(){t.isAdsScriptLoaded()||t.hasAds()||delayedContainer.isShow()||delayedContainer.showDelayedContent()},Math.max(0,250-Helper.duration(delayedContainer.getLoadTime()))),setTimeout(function(){delayedContainer.showFallbackContent()},t.isAdsScriptLoaded()?1e3:1500)}),this},setAdsScriptLoaded:function(t){this._adsScriptLoaded=t},isAdsScriptLoaded:function(){return this._adsScriptLoaded},setAdsAmount:function(t){this._adsAmount=t},hasAds:function(){return 0<this._adsAmount},sendStatistics:function(){var t=statisticsLog.additionalResult.data;t.ads_loaded=!0,t.ads_amount=this._adsAmount,t.ads_time=Helper.duration(this._adsLoadTime),t.ads_type="g",statisticsLog.sendAdditionalData()}}}function gAdsScriptLoaded(){googleAds.setAdsScriptLoaded(!0)}function gAdsUnitLoaded(e,t){var a=t?(delayedContainer.showSearchResultsTitle(),delayedContainer.showDelayedContent(),function(t){ClassList.add(t,"search-container__csa--loaded"),delayedContainer.showFallbackContentElement(t,!1)}):function(t){ClassList.add(t,"search-container__csa--empty"),delayedContainer.showFallbackContentElement(t,!0)};appReady.push(function(){var t=document.getElementById(e);t&&a(t)})}function gAdsResponse(t){var e,a=0;for(e in t)t.hasOwnProperty(e)&&0<t[e]&&(a+=t[e]);googleAds.setAdsAmount(a),appReady.push(function(){googleAds.hasAds()||delayedContainer.showDelayedContent(),googleAds.sendStatistics()})}try{var googleAds=(new GoogleAds).create()}catch(t){logError(t)}</script>
<script>
    try {    _googCsa('ads', {"pubId": "izito-smh-iex", "query": "solicitar cartao Hipercard", "adtest": "off", "linkTarget": "_blank", "adsafe": "low", "hl": "pt", "channel": "iz_br_gb_1_cg1_05", "adPage": 1, "numRepeated": 4}, {"container": "csa-top", "styleId": 7169977672, "adLoadedCallback": window.gAdsUnitLoaded || null, "adsResponseCallback": window.gAdsResponse || null, "clicktrackUrl": ["https:\/\/www.izito.com.br\/tp?locale=pt_BR&q=solicitar%20cartao%20Hipercard&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H&tpt=1647005921&type=g"], "maxTop": 4}, {"container": "csa-bottom", "styleId": 7169977672, "adLoadedCallback": window.gAdsUnitLoaded || null, "clicktrackUrl": ["https:\/\/www.izito.com.br\/tp?locale=pt_BR&q=solicitar%20cartao%20Hipercard&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H&tpt=1647005921&type=g"], "number": 5});_googCsa('jsLoadedCallback', window.gAdsScriptLoaded || null);
    } catch (error) {
    logError(error);
}</script>
<style>@font-face{font-family:"visymo";src:url("/build/fonts/visymo/visymo.eot?v7");src:url("/build/fonts/visymo/visymo.eot?v7#iefix") format("embedded-opentype"),url("/build/fonts/visymo/visymo.woff2?v7") format("woff2"),url("/build/fonts/visymo/visymo.woff?v7") format("woff"),url("/build/fonts/visymo/visymo.ttf?v7") format("truetype"),url("/build/fonts/visymo/visymo.svg?v7#visymo") format("svg");font-weight:normal;font-style:normal;font-display:block}*,*:before,*:after{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;margin:0;padding:0;vertical-align:top}html{background:#fff;font-size:62.5%;text-align:left;-webkit-text-size-adjust:none}body{background-color:#fff;font:400 15px/15px arial,helvetica,sans-serif;font:400 1.5rem/1.5rem arial,helvetica,sans-serif;-webkit-font-smoothing:antialiased}html,body{height:100%;width:100%}img{border:0;display:block;font-size:1px;font-size:.1rem;overflow:hidden}input,button{-webkit-appearance:none;background-image:none;-webkit-border-radius:0;border-radius:0}input::-ms-clear{display:none}button{-webkit-appearance:none;border:0;border-collapse:separate;cursor:pointer;outline:0}button::-moz-focus-inner{border:0;padding:0}ul{list-style:none}div{display:block}a{color:#2775BD;text-decoration:none}.vsi:after,.vsi:before{display:block;font-family:visymo;-webkit-font-smoothing:antialiased;font-weight:400;-moz-osx-font-smoothing:grayscale;text-rendering:auto}.clear{clear:both}.auto-suggest{background:#fff;border:1px solid #999;border:.1rem solid #999;-webkit-border-radius:0 0 .3rem .3rem;border-radius:0 0 .3rem .3rem;border-top:0;-webkit-box-shadow:0 0.3rem 0.3rem rgba(20,23,26,0.1);box-shadow:0 0.3rem 0.3rem rgba(20,23,26,0.1);display:none;font-size:16px;font-size:1.6rem;left:0;line-height:28px;line-height:2.8rem;margin-top:-1px;margin-top:-.1rem;overflow:auto;position:absolute;right:0;text-align:left;z-index:999}.auto-suggest--visible{display:block}.auto-suggest__separator{display:none}.auto-suggest__icon{color:#C2C1C0;cursor:pointer;height:28px;height:2.8rem;position:absolute;right:0;text-align:center;top:0;width:50px;width:5rem}.auto-suggest__icon--append:before{content:"";font-size:18px;font-size:1.8rem;text-align:center}.auto-suggest__icon--search:before{content:"";font-size:20px;font-size:2rem;text-align:center}.auto-suggest__item{color:#666;cursor:pointer;font-weight:700;height:28px;height:2.8rem;line-height:28px;line-height:2.8rem;overflow:hidden;padding:0 10px;padding:0 1rem;position:relative;white-space:nowrap}.auto-suggest__item strong{font-weight:400}.auto-suggest__item--active{background:#eee;color:#666}.auto-suggest__item--active .auto-suggest__icon{color:#592260}.auto-suggest__item--history{color:#2775BD}.auto-suggest__item--erase-history{background:transparent;color:#2775BD;font-size:13px;font-size:1.3rem;font-weight:400;height:34px;height:3.4rem;line-height:34px;line-height:3.4rem}.auto-suggest__item--erase-history .auto-suggest__term:hover{text-decoration:underline}.base{color:#666;display:table;min-height:100%;min-width:100%}.base__main{display:table-row;height:100%}.base__footer{display:table-row}@supports ((display: -webkit-flex) or (display: flex)){.base{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-orient:vertical;-webkit-box-direction:normal;-webkit-flex-direction:column;-moz-box-orient:vertical;-moz-box-direction:normal;-ms-flex-direction:column;flex-direction:column}.base__main{display:block;-webkit-box-flex:1;-webkit-flex:1 0 auto;-moz-box-flex:1;-ms-flex:1 0 auto;flex:1 0 auto;height:auto;min-height:100%}.base__footer{display:block;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0}}.clear-input{display:none;position:absolute;right:5px;right:.5rem;top:0;z-index:1}.clear-input__button{background:rgba(0,0,0,0);border-right:0;height:38px;height:3.8rem;line-height:38px;line-height:3.8rem;width:30px;width:3rem}.clear-input__button-text{color:#A0A0B0;font-size:20px;font-size:2rem}.clear-input__button-text:before{content:""}.clear-input--visible{display:block}.content-paragraph{color:#666;font-size:12.5px;font-size:1.25rem;line-height:18px;line-height:1.8rem;margin-bottom:14px;margin-bottom:1.4rem;margin-top:14px;margin-top:1.4rem;word-break:break-word;word-wrap:break-word}.content-paragraph__header{font-size:12.5px;font-size:1.25rem;line-height:18px;line-height:1.8rem;margin:0;padding:0}.content-paragraph__link:hover{text-decoration:underline}.content-paragraph__list{display:block;padding:10px 40px;padding:1rem 4rem}.content-paragraph__list--disc{list-style-type:disc}@media (min-width: 992px){.content-paragraph{width:66.66666667%}}@media (min-width: 1200px){.content-paragraph{width:67rem}}@media (min-width: 1400px){.content-paragraph{width:77.5rem}}.content-unordered-list{color:#505058;font:400 14px/20px arial,helvetica,sans-serif;font:400 1.4rem/2rem arial,helvetica,sans-serif;list-style-position:inside;list-style-type:disc;margin-bottom:14px;margin-bottom:1.4rem;margin-top:14px;margin-top:1.4rem}.content-unordered-list__item{margin-bottom:2px;margin-bottom:.2rem;margin-left:10px;margin-left:1rem;margin-top:2px;margin-top:.2rem}.error-message-container{margin:25px 0 18px 0;margin:2.5rem 0 1.8rem 0}.footer{font-size:13px;font-size:1.3rem;padding-bottom:10px;padding-bottom:1rem;padding-top:10px;padding-top:1rem;position:relative;text-align:center;width:100%}.footer__nav-container{display:block;line-height:26px;line-height:2.6rem;padding:0 15px;padding:0 1.5rem}.footer-nav{text-align:center}.footer-nav__item{display:inline;padding:0 8px;padding:0 .8rem}.footer-nav__item--copyright{display:block;margin-top:10px;margin-top:1rem}.footer-nav__link{color:#666;white-space:nowrap}.footer-nav__link:hover{text-decoration:underline}@media (max-width: 767px){.footer-nav{font-size:1.4rem}}@media (min-width: 0px){.footer-nav__item{padding:0}.footer-nav__item:before{content:"-";display:inline-block;padding:0 .8rem}.footer-nav__item:first-child:before,.footer-nav__item--copyright:before{display:none}}.list-head{margin-bottom:10px;margin-bottom:1rem}.list-head__title{color:#777;font:400 16px/16px arial,helvetica,sans-serif;font:400 1.6rem/1.6rem arial,helvetica,sans-serif;word-break:break-word;word-wrap:break-word}.list-head__link{color:inherit}.list-head__link:hover{text-decoration:underline}.list-head--small .list-head__title{font:400 14px/15px arial,helvetica,sans-serif;font:400 1.4rem/1.5rem arial,helvetica,sans-serif}.device-c .list-head__title{color:#A0A0B0}.device-m .list-head,.device-t .list-head{margin-bottom:5px;margin-bottom:.5rem}.device-m .list-head__title,.device-t .list-head__title{font-size:13px;font-size:1.3rem;line-height:18px;line-height:1.8rem}@media (max-width: 991px){.list-head{margin-bottom:.5rem}.list-head__title{font-size:1.3rem;line-height:1.8rem}}.media-query{background:transparent;bottom:0;display:block;height:0;left:0;position:fixed;width:0}.media-query li{display:none}@media (min-width: 1400px){.media-query li:nth-child(6){display:inline-block}}@media (max-width: 1399px){.media-query li:nth-child(5){display:inline-block}}@media (max-width: 1199px){.media-query li:nth-child(4){display:inline-block}}@media (max-width: 991px){.media-query li:nth-child(3){display:inline-block}}@media (max-width: 767px){.media-query li:nth-child(2){display:inline-block}}@media (max-width: 499px){.media-query li:nth-child(1){display:inline-block}}.search-field{background:#fff;min-height:40px;min-height:4rem;position:relative}.search-field--align-center{margin:0 auto}.search-field__submit{overflow:hidden;position:absolute;right:0;top:0;width:50px;width:5rem}.search-field__submit-button{background:#592260;color:#fff;height:40px;height:4rem;overflow:hidden;position:relative;width:50px;width:5rem}.search-field__submit-button:before{content:"";display:block;font-size:14px;font-size:1.4rem;height:40px;height:4rem;line-height:40px;text-align:center;width:50px;width:5rem}.search-field__submit-button:focus{color:#fff}.search-field__submit-button:focus:before{background:#592260}.search-field__submit-button-text{color:#fff}.search-field__query{border:1px solid #ddd;border:.1rem solid #ddd;border-right:0;display:block;height:40px;height:4rem;margin-right:50px;margin-right:5rem;position:relative}.search-field__query-input{background:transparent;border:0;color:#505058;display:block;font-size:16px;font-size:1.6rem;height:38px;height:3.8rem;left:0;line-height:38px;line-height:3.8rem;margin:0;outline:0;padding:0 10px;padding:0 1rem;position:absolute;right:0;top:0;width:100%}.search-field__query-input:focus{border-color:#999}.search-field--auto-suggest .search-field__query{border-color:#999}.search-bar{position:relative}.search-bar--align-center{margin:0 auto}.search-bar--full-width{max-width:none;width:100%}.search-bar__inner{display:block;position:relative}@media (max-width: 767px){.search-bar__inner--with-menu{padding-right:0}}@media (min-width: 0px){.search-bar--full-width{max-width:none}}</style>
<noscript>
    <style>
        .search-container__results-inner {
            visibility: visible !important;
        }
    </style>
</noscript>
<style></style>

                

    <style>.related-terms{display:block;float:left;margin-right:30px;margin-right:3rem;min-width:190px;min-width:19rem}.related-terms__item{display:block}.related-terms__link{color:#1A0DAB;display:inline-block;font-size:16px;font-size:1.6rem;line-height:34px;line-height:3.4rem;text-decoration:none}.related-terms__link:hover{text-decoration:underline}@media (max-width: 767px){.related-terms{float:none;margin-right:0;min-width:auto}.related-terms__item{border-bottom:0.1rem solid #eee}.related-terms__link{display:block;padding:.4rem 0;position:relative;text-decoration:none}.related-terms__link:hover{text-decoration:none}.related-terms__link:before{color:#000;content:"";position:absolute;right:0}.related-terms--expanded,.related-terms__item:nth-child(n+7){display:none}}.device-m .related-terms,.device-t .related-terms{float:none;margin-right:0;min-width:auto}.device-m .related-terms__item,.device-t .related-terms__item{border-bottom:1px solid #eee;border-bottom:0.1rem solid #eee}.device-m .related-terms__link,.device-t .related-terms__link{display:block;padding:4px 0;padding:.4rem 0;position:relative;text-decoration:none}.device-m .related-terms__link:hover,.device-t .related-terms__link:hover{text-decoration:none}.device-m .related-terms__link:before,.device-t .related-terms__link:before{color:#000;content:"";position:absolute;right:0}.device-m .related-terms__link,.device-t .related-terms__link{color:#2800C8}@media (min-width: 992px){.related-terms--compact .related-terms__link{color:#2775BD;font-size:1.4rem;line-height:2rem}}.related-terms-container{margin:10px 0 18px 0;margin:1rem 0 1.8rem 0}.related-terms-container--aside{margin-top:0}.wiki-excerpt{margin-bottom:20px;margin-bottom:2rem}.wiki-excerpt__description{color:#505058;font-size:13px;font-size:1.3rem;line-height:15px;line-height:1.5rem}.wiki-excerpt__thumbnail{float:right;padding:0 0 10px 10px;padding:0 0 1rem 1rem}.wiki-excerpt__read-more-link{color:inherit}.wiki-excerpt__read-more-link:hover{text-decoration:underline}.footer-logo{display:none;margin-bottom:16px;margin-bottom:1.6rem;margin-top:12px;margin-top:1.2rem}.footer-logo__brand-image{height:28px;height:2.8rem;margin-left:auto;margin-right:auto;width:88px;width:8.8rem}@media (max-width: 767px){.footer-logo{display:block}}.main-menu{font-size:13px;font-size:1.3rem;height:35px;height:3.5rem;padding:2px 0 0 0;padding:.2rem 0 0 0}.main-menu__item{display:inline;padding:0 9px;padding:0 .9rem;position:relative}@media (min-width: 0px){.main-menu__item{display:inline-block}}.main-menu__item--more{display:none}.main-menu__link{color:#777;display:inline-block;line-height:33px;line-height:3.3rem;white-space:nowrap}.main-menu__link--active,.main-menu__link:hover{color:#393E46}.main-menu__link--active{font-weight:700}.main-menu--sub{position:absolute;right:20px;right:2rem;top:0;white-space:nowrap}.main-menu--sub .main-menu__item:last-child{padding-right:0}@media (max-width: 767px){.main-menu--sub{display:none}.main-menu__item--additional{display:none}.main-menu__item--more{display:inline-block}}.more-menu{display:inline-block;position:relative}.more-menu__label{border-bottom:4px solid transparent;border-bottom:.4rem solid transparent;color:#777;cursor:pointer;display:block;line-height:34px;line-height:3.4rem;padding:0 9px;padding:0 .9rem;position:relative}.more-menu__text{display:inline-block}.more-menu__icon{color:#592260;display:inline-block;font-size:12px;font-size:1.2rem;margin-left:4px;margin-left:.4rem}.more-menu__icon:before{content:""}.more-menu__hamburger-icon{background:#eee;-webkit-border-radius:50%;border-radius:50%;color:#592260;cursor:pointer;display:block;height:34px;height:3.4rem;line-height:34px;line-height:3.4rem;overflow:hidden;text-align:center;width:34px;width:3.4rem}.more-menu__hamburger-icon:before{content:"";font-size:24px;font-size:2.4rem}.more-menu__select{line-height:42px;line-height:4.2rem;margin-top:1px;margin-top:.1rem;position:absolute;z-index:3}.more-menu__select--hidden{display:none}.more-menu__select-list{background:#fff;border:1px solid #C2C1C0;border:0.1rem solid #C2C1C0;position:absolute}.more-menu__select-item{display:block}.more-menu__select-link{color:#505058;display:block;padding:0 9px;padding:0 .9rem;white-space:nowrap}.more-menu__select-link:hover{background-color:#eee}.more-menu__select-link--active{color:#592260}@media (max-width: 767px){.more-menu{margin-bottom:1rem;width:100%}.more-menu__label{width:100%}.more-menu__select-list{position:relative}}@media (min-width: 0px){.more-menu__select-list{border:0;-webkit-box-shadow:0 0 1rem 0 rgba(0,0,0,0.12);box-shadow:0 0 1rem 0 rgba(0,0,0,0.12)}}.search-container__results{float:left;margin-left:77px;margin-left:7.7rem;max-width:651px;max-width:65.1rem;width:100%}.search-container__results-inner{padding-left:15px;padding-left:1.5rem;padding-right:15px;padding-right:1.5rem}.search-container__results-inner--top-space{margin-top:10px;margin-top:1rem}.search-container__results-inner--hidden{display:none}.search-container__results-title{color:#70757A;font-size:14px;font-size:1.4rem;font-weight:400;line-height:20px;line-height:2rem;margin-top:5px;margin-top:.5rem;min-height:20px;min-height:2rem}.search-container__results .search-results--a .search-results__badge,.search-container__results .search-results--a .search-results__display-url{color:#0E7744}.search-container__results .search-results--a .search-results__display-url strong{font-weight:normal}.search-container__csa{padding-left:11px;padding-left:1.1rem;padding-right:15px;padding-right:1.5rem}.search-container__aside{float:left;max-width:234px;max-width:23.4rem;padding:5px 15px 10px;padding:0.5rem 1.5rem 1rem;width:100%}.search-container__aside .search-container__results-inner{padding-left:0}.search-container__aside .list-head__title{color:#777;font-size:13px;font-size:1.3rem;line-height:15px;line-height:1.5rem}@media (min-width: 1400px){.search-container__results{margin-left:10.6rem;max-width:77.9rem}.search-container__aside{max-width:47rem}}@media (min-width: 1200px) and (max-width: 1399px){.search-container__results{margin-left:10.6rem;max-width:67.4rem}.search-container__aside{max-width:39rem}}@media (max-width: 991px){.search-container__results{float:none;margin-left:0;max-width:none}.search-container__aside{float:none;margin-top:3rem;max-width:none}}@media (max-width: 767px){.search-container{margin-bottom:0}}.search-header{background-color:#FCFCFC;border-bottom:1px solid #eee;border-bottom:0.1rem solid #eee;margin-bottom:10px;margin-bottom:1rem;padding:0 128px 11px 77px;padding:0 12.8rem 1.1rem 7.7rem;position:relative}.search-header__nav{max-width:636px;max-width:63.6rem;padding-left:15px;padding-left:1.5rem}@media (min-width: 1400px){.search-header__nav{max-width:76.4rem}}@media (min-width: 1200px) and (max-width: 1399px){.search-header__nav{max-width:65.9rem}}@media (max-width: 991px){.search-header__nav{max-width:none}}.search-header__aside{position:absolute;right:0;top:0}.search-header__aside-link{display:block}.search-header__brand-link{position:absolute;right:20px;right:2rem;top:42px;top:4.2rem}.search-header__brand-image{display:block;height:28px;height:2.8rem;width:88px;width:8.8rem}@media (min-width: 1400px){.search-header{padding-left:10.6rem}}@media (min-width: 1200px){.search-header{padding-left:10.6rem}}@media (max-width: 991px){.search-header{padding-left:0}}@media (max-width: 767px){.search-header{padding-right:1.5rem;padding-top:0}.search-header__nav-bar{display:block}.search-header__aside{display:none}}.body--overlay{overflow:hidden;position:relative}.overlay{background-color:rgba(0,0,0,0.45);border-top:3px solid #592260;border-top:.3rem solid #592260;content:"";display:block;height:100%;left:0;position:fixed;top:0;width:100%;z-index:1000}.overlay--hidden{display:none}.overlay-menu{background:transparent;bottom:0;display:block;height:100%;left:0;max-width:400px;max-width:40rem;overflow:hidden;position:fixed;right:40px;right:4rem;text-align:left;top:3px;top:.3rem;z-index:1500}.overlay-menu--hidden{display:none}.overlay-menu__inner{background:#fff;bottom:0;height:100%;left:0;-webkit-overflow-scrolling:touch;overflow-x:hidden;overflow-y:auto;padding:25px;padding:2.5rem;position:relative;right:0;top:0}.overlay-menu__head{height:50px;height:5rem}.overlay-menu__items{line-height:35px;line-height:3.5rem}.overlay-menu__item{padding:4px 0;padding:.4rem 0}.overlay-menu__link{color:#505058;display:inline-block}.device-m .search-header__nav{padding-left:15px;padding-left:1.5rem}.device-m .search-header .main-menu__item:first-child{padding-left:17px;padding-left:1.7rem}.device-m .search-header .search-field__query-input,.device-m .search-header .auto-suggest__item{padding-left:16px;padding-left:1.6rem}.device-t .search-header__nav{padding-left:15px;padding-left:1.5rem}.device-t .search-header .main-menu__item:first-child{padding-left:17px;padding-left:1.7rem}.device-t .search-header .search-field__query-input,.device-t .search-header .auto-suggest__item{padding-left:16px;padding-left:1.6rem}.device-c .search-header .search-field__query-input,.device-c .search-header .auto-suggest__item{padding-left:9px;padding-left:.9rem}.device-c .search-header .main-menu__item:first-child{padding-left:10px;padding-left:1rem}@media (min-width: 992px){.device-c .search-header__nav{padding-left:.9rem}}.device-m .search-container__results .search-container__results-inner{padding-left:15px;padding-left:1.5rem;padding-right:15px;padding-right:1.5rem}.device-m .search-container__csa{padding-left:15px;padding-left:1.5rem;padding-right:15px;padding-right:1.5rem}@media (min-width: 500px){.device-m .search-container__results .search-container__results-inner{padding-left:3.2rem;padding-right:1.5rem}}.device-t .search-container__results .search-container__results-inner{padding-left:15px;padding-left:1.5rem;padding-right:15px;padding-right:1.5rem}.device-t .search-container__csa{padding-left:15px;padding-left:1.5rem;padding-right:15px;padding-right:1.5rem}@media (min-width: 500px){.device-t .search-container__results .search-container__results-inner{padding-left:3.2rem;padding-right:1.5rem}}@media (min-width: 500px) and (max-width: 991px){.device-t .search-container__aside{padding-left:0;padding-right:0}.device-t .search-container__aside .search-container__results-inner{padding-left:3.2rem;padding-right:1.5rem}}.device-c .search-container__results{margin-left:81px;margin-left:8.1rem;max-width:647px;max-width:64.7rem}.device-c .search-container__aside{padding-left:0;padding-right:0}.device-c .search-container__aside .search-container__results-inner{padding-left:15px;padding-left:1.5rem;padding-right:15px;padding-right:1.5rem}@media (min-width: 1400px){.device-c .search-container__results{margin-left:11rem;max-width:77.5rem}}@media (min-width: 1200px) and (max-width: 1399px){.device-c .search-container__results{margin-left:11rem;max-width:67rem}}@media (max-width: 991px){.device-c .search-container__results{margin-left:0;max-width:none;padding-left:.9rem}}.device-c #csa-top+.search-container__results-inner--top-space,.device-c #csa-top+.search-container__results-inner .related-terms-container{margin-top:0}.device-c #csa-bottom{margin-top:-12px;margin-top:-1.2rem}.search-results{list-style:none;max-width:600px;max-width:60rem}.search-results__item{margin-bottom:20px;margin-bottom:2rem}.search-results__favicon{display:inline;margin-right:4px;margin-right:.4rem;vertical-align:text-bottom;width:16px;width:1.6rem}.search-results__title{font-size:16px;font-size:1.6rem;font-weight:400;line-height:22px;line-height:2.2rem}.search-results__link{color:#1A0DAB}.search-results__link:hover{text-decoration:underline}.search-results__description{color:#505058;font-size:14px;font-size:1.4rem;line-height:20px;line-height:2rem}.search-results__display-url{color:#505058;font-size:14px;font-size:1.4rem;font-style:normal;line-height:20px;line-height:2rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.device-m .search-results,.device-t .search-results{max-width:none}.device-m .search-results__item,.device-t .search-results__item{margin-bottom:15px;margin-bottom:1.5rem}.device-m .search-results__title,.device-t .search-results__title{font-size:14px;font-size:1.4rem;line-height:16px;line-height:1.6rem}.device-m .search-results__description,.device-t .search-results__description{color:#666;font-size:13px;font-size:1.3rem;line-height:16px;line-height:1.6rem}.device-m .search-results__display-url,.device-t .search-results__display-url{color:#666;font-size:13px;font-size:1.3rem;line-height:20px;line-height:2rem}.device-m .organic-results-component .list-head,.device-t .organic-results-component .list-head{display:none}.device-m .search-container__aside .search-results--a .search-results__title,.device-t .search-container__aside .search-results--a .search-results__title{font-size:15px;font-size:1.5rem}.device-m .search-container__aside .search-results--a .search-results__description,.device-t .search-container__aside .search-results--a .search-results__description{color:#393E46}.device-m .search-results__link,.device-t .search-results__link{color:#2800C8}.device-m .organic-results-component .search-results__title{font-size:16px;font-size:1.6rem;line-height:16px;line-height:1.6rem}.device-m .organic-results-component .search-results__link{display:inline-block;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}@media (max-width: 991px){.device-c .search-results{max-width:none}.device-c .search-results__item{margin-bottom:1.5rem}.device-c .search-results__title{font-size:1.4rem;line-height:1.6rem}.device-c .search-results__description{color:#666;font-size:1.3rem;line-height:1.6rem}.device-c .search-results__display-url{color:#666;font-size:1.3rem;line-height:2rem}.device-c .search-container__aside .search-results--a .search-results__title{font-size:1.5rem}.device-c .search-container__aside .search-results--a .search-results__description{color:#393E46}}.sitelinks{display:block;font-size:15px;font-size:1.5rem;line-height:22px;line-height:2.2rem;margin:6px 0 0 12px;margin:.6rem 0 0 1.2rem}.sitelinks__column{float:left;margin-right:20px;margin-right:2rem;min-width:190px;min-width:19rem}.sitelinks__item{display:block}.sitelinks__link{color:#1A0DAB;display:inline;white-space:nowrap}.sitelinks__link:hover{text-decoration:underline}.device-m .sitelinks,.device-t .sitelinks{font-size:13px;font-size:1.3rem;line-height:20px;line-height:2rem}@media (max-width: 991px){.sitelinks{font-size:1.3rem;line-height:2rem}}.seller-rating{line-height:16px;line-height:1.6rem;margin-top:6px;margin-top:.6rem;position:relative}.seller-rating__stars-container{height:13px;height:1.3rem;left:0;position:absolute;top:0;width:66px;width:6.6rem}.seller-rating__stars-inactive{display:inline;height:13px;height:1.3rem;margin-top:1px;margin-top:.1rem;width:66px;width:6.6rem}.seller-rating__stars-active{background:url("/build/images/icon/star-on.png") no-repeat;display:block;height:13px;height:1.3rem;left:0;position:absolute;top:1px;top:.1rem}.seller-rating__domain{color:#505058;display:inline;font-size:14px;font-size:1.4rem}.seller-rating__domain--link:hover{text-decoration:underline}.page-wsd .base__main{margin-left:auto;margin-right:auto;max-width:670px;max-width:67rem}.page-wsd .search-header{padding-left:0;padding-right:0}.page-wsd .search-container__results{margin-left:0;max-width:inherit}.page-wsd #csa-top{margin-top:20px;margin-top:2rem}.collapse-children__children{display:none}.collapse-children__link{color:#592260;display:inline-block;margin-left:10px;margin-left:1rem}.collapse-children__link:before{content:"";font-size:38px;font-size:3.8rem}.page-dsr .base__main{display:block;margin-left:auto;margin-right:auto;max-width:660px;max-width:66rem;padding-bottom:50px;padding-bottom:5rem}.page-dsr .search-header{background:none;border-bottom:none;padding-left:0;padding-right:15px;padding-right:1.5rem}.page-dsr .search-header__nav-bar{height:20px;height:2rem}@media (max-width: 991px){.page-dsr .search-header__brand-link{display:none}}@media (min-width: 768px){.page-dsr .search-header .search-field__query-input{padding-left:1.6rem}}.page-dsr .base .search-header__brand-link{top:27px;top:2.7rem}.page-dsr .search-container__results .search-container__results-inner{padding-left:15px;padding-left:1.5rem;padding-right:15px;padding-right:1.5rem}.page-dsr .search-results{max-width:none}.page-dsr .search-results__title{font-size:15px;font-size:1.5rem;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}@media (max-width: 767px){.page-dsr .search-results{margin-top:2rem}.page-dsr .search-results__title{font-size:1.4rem;margin-bottom:.4rem}.page-dsr .search-results__item{margin-bottom:1.8rem}}@media (min-width: 768px){.page-dsr .search-results{padding:1.5rem 0 0 1.2rem}.page-dsr .search-results__item{margin-bottom:2.5rem}.page-dsr .search-results__display-url{float:right;width:20%}.page-dsr .search-results__description{padding-right:1.6rem;width:80%}}.page-dsr .search-results__display-url-link{color:inherit}.page-dsr .search-container__results{margin-left:0;max-width:inherit}.page-dsr .search-container__results-inner--hidden{display:none}.page-dsr .collapse-children{margin-bottom:25px;margin-bottom:2.5rem}.page-dsr .collapse-children .search-container__results-inner--top-space{margin-top:0}.page-dsr .collapse-children .search-results{padding-top:0}@media (min-width: 768px){.page-dsr .collapse-children__link{margin-left:2rem}}.page-dsr .footer{border-top:3px solid #592260;border-top:0.3rem solid #592260}@media (min-width: 768px){.page-dsr .related-terms{float:none;margin-right:0;min-width:auto}.page-dsr .related-terms__item{border-bottom:0.1rem solid #eee}.page-dsr .related-terms__link{display:block;padding:.4rem 0;position:relative;text-decoration:none}.page-dsr .related-terms__link:hover{text-decoration:none}.page-dsr .related-terms__link:before{color:#000;content:"";position:absolute;right:0}.page-dsr .related-terms-container{font-weight:700;padding-left:1.2rem}.page-dsr .organic-results-title-component .list-head{padding-left:1.2rem}}#search-results-title-container,#search-results-stats-title-data{display:none}@media (min-width: 992px) and (max-width: 1399px){.wiki-excerpt__thumbnail{display:none}}</style>
        <link rel="apple-touch-icon" sizes="180x180" href="/images/logo/icon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/images/logo/icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/images/logo/icon/favicon-16x16.png">
<link rel="manifest" href="/site.webmanifest">
<link rel="mask-icon" href="/images/logo/icon/safari-pinned-tab.svg" color="#592260">
<meta name="msapplication-TileColor" content="#592260">
<meta name="theme-color" content="#FFFFFF">
    </head>
    <body class="body">
            <div class="base">
        <div class="base__main">
                                                <div class="search-header"><div class="search-header__nav"><div class="search-header__nav-bar"><ul class="main-menu"><li class="main-menu__item"><a href="index.php" class="main-menu__link main-menu__link--active">Web</a></li><li class="main-menu__item main-menu__item--additional"><a href="index.php" class="main-menu__link">Imagens</a></li><li class="main-menu__item main-menu__item--additional"><a href="index.php" class="main-menu__link">Vídeo</a></li><li class="main-menu__item main-menu__item--additional"><a href="index.php" class="main-menu__link">Notícia</a></li><li class="main-menu__item main-menu__item--more"><div class="more-menu"><div class="more-menu__label"><span class="more-menu__text">Mais</span><span class="more-menu__icon vsi"></span></div><div class="more-menu__select more-menu__select--hidden"><ul class="more-menu__select-list"><li class="more-menu__select-item"><a href="index.php" class="more-menu__select-link">Avançada</a></li><li class="more-menu__select-item"><a href="index.php" class="more-menu__select-link">Suas configurações de busca</a></li></ul></div></div></li></ul></div><div class="search-header__search-bar"><form method="get" action="/" class="search-bar" data-auto-suggest="1"><div class="search-bar__inner"><div class="search-field" data-erase-history-label="apagar pesquisas anteriores"><label class="search-field__query"><input type="text" name="q" autocomplete="off" value="Fatura Hipercard" class="search-field__query-input" data-clear-option="1" placeholder=""></label><div class="search-field__submit"><button type="submit" class="search-field__submit-button vsi"><span class="search-field__submit-button-text">busca</span></button></div><div class="auto-suggest"></div></div></div><input type="hidden" name="locale" value="pt_BR"><input type="hidden" name="vid" value="f49c1671-3c10-43da-a187-b4beca435d82"><input type="hidden" name="ste" value="Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H"></form></div></div><div class="search-header__aside"><ul class="main-menu main-menu--sub"><li class="main-menu__item"><a href="index.php" class="main-menu__link">Suas configurações de busca</a></li><li class="main-menu__item"><a href="index.php" class="main-menu__link">Avançada</a></li></ul><a href="index.php" class="search-header__brand-link"><img src="/images/logo/izito-logo.png" alt="iZito" class="search-header__brand-image"></a></div></div>                                        <div class="search-container">
                <div class="search-container__results">
                                                <div class="search-container__results-inner" id="delayed-container-1" style="visibility: hidden;">
    <div id="search-results-title" class="search-container__results-title">&nbsp;</div>
</div>

        <div id="csa-top" class="search-container__csa"></div>

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
        <div class="component related-terms-component search-container__results-inner" id="delayed-container-2" style="visibility: hidden;">
    <div class="related-terms-container">
            
                    
    <div class="list-head list-head--small">
        <h4 class="list-head__title">Pesquisas relacionadas a <strong>Fatura Hipercard</strong></h4>
    </div>

                            <ul class="related-terms">
                                                                                <li class="related-terms__item">
                            <a href="index.php"
                               title="Fatura cartao credito Hipercard"
                               class="related-terms__link vsi"
                            ><strong>Fatura Cartao</strong> Credito  <strong>Hipercard</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php"
                               title="cartao Hipercard Fatura online"
                               class="related-terms__link vsi"
                            ><strong>Cartao</strong> Hipercard <strong> Fatura</strong> Online</a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php"
                               title="Fatura o cartao Hipercard"
                               class="related-terms__link vsi"
                            ><strong>Fatura</strong> O <strong>Cartao</strong> <strong>Hipercard</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php"
                               title="Fatura cartao do Hipercard"
                               class="related-terms__link vsi"
                            ><strong>Fatura Cartao</strong>  <strong>Hipercard</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="Hipercard cred Fatura cartao"
                               class="related-terms__link vsi"
                            ><strong>Hipercard</strong> Cred <strong>Fatura Cartao</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="solicitar cartao de credito Hipercard"
                               class="related-terms__link vsi"
                            ><strong>Fatura Cartao</strong> De Credito   <strong>Hipercard</strong></a>
                        </li>
                                                                                                        </ul>
                    <ul class="related-terms related-terms--expanded">
                                                                                                                                        <li class="related-terms__item">
                            <a href="index.php" title="Saldo cartao Hipercard"
                               class="related-terms__link vsi"
                            ><strong>Saldo Cartao</strong>   <strong>Hipercard</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="cartao Hipercard saldo"
                               class="related-terms__link vsi"
                            ><strong>Cartao Hipercard saldo</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="Saldo cartao Hipercard internet"
                               class="related-terms__link vsi"
                            ><strong>Saldo Cartao</strong>   <strong>Hipercard</strong> Internet</a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="Consultar cartao Hipercard ouro"
                               class="related-terms__link vsi"
                            ><strong>Consultar Cartao Hipercard</strong> Ouro</a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="Consultar cartao"
                               class="related-terms__link vsi"
                            ><strong>Consultar Cartao</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="solicitar cartao de credito Hipercard online"
                               class="related-terms__link vsi"
                            ><strong>Solicitar Cartao</strong> De Credito   <strong>Hipercard</strong> Online</a>
                        </li>
                                                </ul>
        
        <div class="clear"></div>
    </div>
</div>


    <div class="search-container__results-inner search-container__results-inner--top-space organic-results-title-component" id="delayed-container-3" style="visibility: hidden;">
                    
                    
    <div class="list-head list-head--small">
        <h4 class="list-head__title">Resultados web</h4>
    </div>
</div>

        <div class="component organic-results-component search-container__results-inner search-container__results-inner--top-space" id="delayed-container-4" style="visibility: hidden;">
        <ol class="search-results">
                                            <li class="search-results__item">
                    <div class="search-results__title">
                                                                            <a href="index.php"
                               rel="nofollow noopener noreferrer"  class="search-results__link" target="_blank"
                                
                            >Hipercard: Como consultar o seu cartão - PortalFinança.com</a>
                                            </div>
                    <div class="search-results__display-url">
                                                    www.portalfinanca.com
                                            </div>
                    <p class="search-results__description">
                        Por meio do cartão de crédito do Hipercard você também consegue solicitar um empréstimo pessoal de fácil aprovação e rápida liberação do valor (dinheiro cai na conta em até 48h). O valor do crédito é de até R$31 mil , com parcelamento em até 72x e pagamento da primeira parcela para somente 60 dias após a assinatura do contrato.
                                            </p>
                </li>
                                            <li class="search-results__item">
                    <div class="search-results__title">
                                                                            <a href="index.php"
                               rel="nofollow noopener noreferrer"  class="search-results__link" target="_blank"
                                
                            >Cartão Hipercard: Como Pedir? Vantagens! Saiba emitir 2ª ...</a>
                                            </div>
                    <div class="search-results__display-url">
                                                    www.solicitarcartao.net
                                            </div>
                    <p class="search-results__description">
                        Vantagens do Cartão Hipercard. O Cartão Hipercard está disponível em duas versões: Cartão Hipercard Ouro e Cartão Hipercard Preferencial. Ambos os cartões possuem as mesmas vantagens, porém, a diferença entre os dois está na anuidade, sendo que na versão Preferencial você pagará a anuidade de R$ 95,88 ou 12 parcelas de R$ 7,99, já o Ouro você estará isento de anuidade.
                                            </p>
                </li>
                                            <li class="search-results__item">
                    <div class="search-results__title">
                                                                            <a href="index.php"
                               rel="nofollow noopener noreferrer"  class="search-results__link" target="_blank"
                                
                            >Cartão Hipercard Ouro - FDR</a>
                                            </div>
                    <div class="search-results__display-url">
                                                    fdr.com.br
                                            </div>
                    <p class="search-results__description">
                        Cartão Hipercard Ouro: Peça Agora Sem Anuidade (Consulte a Fatura) Um outro cartão sem anuidade é o cartão de crédito Nubank.Ele já está na lista dos mais queridos do Brasil porque é um cartão moderno, versátil e altamente flexível para o cliente.
                                            </p>
                </li>
                    </ol>
    </div>

            

<script>
        (function(w,d,t,x,m,l,p){w['XMLPlusObject']=m;w[m]=w[m]||function()
        {
            (w[m].q=w[m].q||[]).push(arguments)},w[m].l=1*new Date();
            l=d.createElement(t),p=d.getElementsByTagName(t)[0];
            l.type="text/javascript";
            l.async=1;
            l.defer=1;
            l.src=x;
            p.parentNode.insertBefore(l,p)
        })
        (window,document,'script','https://s.yimg.com/ds/scripts/xmlp.js','xmlp');xmlp('init','vinden_xml_br_arbitrage_google','B0E047B2787E43E3');
    </script>
<div class="search-container__results-inner search-container__results-inner--a a-results-component a-results-component--middle" id="delayed-container-5" style="visibility: hidden;" data-beacon="{&quot;url&quot;:&quot;https:\/\/search.yahoo.com\/beacon\/geop\/p?s=1197807446&amp;ysid=B0E047B2787E43E3&amp;traffic_source=vinden_xml_br_arbitrage_google&quot;}">
    
    <ul class="search-results search-results--a">
                                                                                                <li class="search-results__item search-results__item--a" data-yiid="72430572940868">
                <div class="search-results__title">
                    <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="search-results__link" data-tp="{&quot;type&quot;:&quot;y&quot;,&quot;block&quot;:2,&quot;ad&quot;:1}">Izettle Maquina De <strong>Cartão</strong> - Pesquise Por Info E Resultados</a>
                </div>
                <div class="search-results__display-url"><span class="search-results__badge">Anúncio </span><span class="search-results__display-url-text">www.zapmeta.com.br/Pesquisar</span>
                </div>
                
                <p class="search-results__description">Pesquise com mais rapidez e eficiência aqui! Izettle Maquina De <strong>Cartão</strong><br/>Tipos: pdf, doc, ppt, xls, txt</p>
                                    <div class="sitelinks">
                                                    <ul class="sitelinks__column">
                                                                                                                                                <li class="sitelinks__item">
                                            <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="sitelinks__link">Informações Relacionadas</a>
                                        </li>
                                                                                                                                                                                                                                                                                            <li class="sitelinks__item">
                                            <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="sitelinks__link">Pesquise e Encontre Agora</a>
                                        </li>
                                                                                                                                                                                                        </ul>
                                                    <ul class="sitelinks__column">
                                                                                                                                                                                                                                                        <li class="sitelinks__item">
                                            <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="sitelinks__link">Pesquisa Múltipla</a>
                                        </li>
                                                                                                                                                                                                                                                                                            <li class="sitelinks__item">
                                            <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="sitelinks__link">Encontre Mais</a>
                                        </li>
                                                                                                </ul>
                                                <div class="clear"></div>
                    </div>
                                            </li>
                                                                                                <li class="search-results__item search-results__item--a" data-yiid="80676793256134">
                <div class="search-results__title">
                    <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="search-results__link" data-tp="{&quot;type&quot;:&quot;y&quot;,&quot;block&quot;:2,&quot;ad&quot;:2}">Peça <strong>Cartão</strong> De Crédito Online - <strong>Cartão</strong> Sem Complicação</a>
                </div>
                <div class="search-results__display-url"><span class="search-results__badge">Anúncio </span><span class="search-results__display-url-text">www.serasa.com.br/serasa/<strong>cartao</strong></span>
                </div>
                
                <p class="search-results__description">Pare De Pular De Banco Em Banco Para Pedir Seu <strong>Cartão</strong>. Solicite Grátis Em Nosso Site. Várias Empresas Com Ofertas No Mesmo Lugar. Acesse Agora e Solicite Grátis Seu <strong>Cartão</strong>.<br/>Cartão sem Anuidade · Compare Vários Cartões · Solicite Online</p>
                                    <div class="sitelinks">
                                                    <ul class="sitelinks__column">
                                                                                                                                                <li class="sitelinks__item">
                                            <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="sitelinks__link">Rápido e Seguro</a>
                                        </li>
                                                                                                                                                                                                                                                                                            <li class="sitelinks__item">
                                            <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="sitelinks__link">Empréstimo Pessoal</a>
                                        </li>
                                                                                                                                                                                                                                                                                            <li class="sitelinks__item">
                                            <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="sitelinks__link">Cartão Sem Anuidade</a>
                                        </li>
                                                                                                                                                                                                        </ul>
                                                    <ul class="sitelinks__column">
                                                                                                                                                                                                                                                        <li class="sitelinks__item">
                                            <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="sitelinks__link">Cartão de Crédito</a>
                                        </li>
                                                                                                                                                                                                                                                                                            <li class="sitelinks__item">
                                            <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="sitelinks__link">Empréstimo</a>
                                        </li>
                                                                                                                                                                                                                                                                                            <li class="sitelinks__item">
                                            <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="sitelinks__link">Serasa eCred</a>
                                        </li>
                                                                                                </ul>
                                                <div class="clear"></div>
                    </div>
                                            </li>
            </ul>
</div>




        <div class="component organic-results-component search-container__results-inner search-container__results-inner--top-space" id="delayed-container-6" style="visibility: hidden;">
        <ol class="search-results">
                                            <li class="search-results__item">
                    <div class="search-results__title">
                                                                            <a href="index.php"
                               rel="nofollow noopener noreferrer"  class="search-results__link" target="_blank"
                                
                            >Como solicitar cartão de crédito Hipercard? - Passo a passo</a>
                                            </div>
                    <div class="search-results__display-url">
                                                    escolaeducacao.com.br
                                            </div>
                    <p class="search-results__description">
                        Lojas Hipercard. Caso prefira, também é possível solicitar o cartão a partir da loja física mais próxima de você. Para isso, é necessário apresentar o documento de identidade com foto, comprovante de residência e comprovante de renda. Em todos os casos de solicitação, seus dados estarão sujeitos a uma análise de crédito.
                                            </p>
                </li>
                                            <li class="search-results__item">
                    <div class="search-results__title">
                                                                            <a href="index.php"
                               rel="nofollow noopener noreferrer"  class="search-results__link" target="_blank"
                                
                            >Cartão de Crédito Hipercard: Avaliação e como fazer/solicitar o seu!</a>
                                            </div>
                    <div class="search-results__display-url">
                                                    fdr.com.br
                                            </div>
                    <p class="search-results__description">
                        Cartão de Crédito Hipercard: Avaliação e como fazer/solicitar o seu! (Imagem: Divulgação Hipercard) Banco emissor. O cartão de crédito da Hipercard possui parceria com o banco Itaú, com a distribuição feita por meio da fintech Hipercardcred.
                                            </p>
                </li>
                                            <li class="search-results__item">
                    <div class="search-results__title">
                                                                            <a href="index.php"
                               rel="nofollow noopener noreferrer"  class="search-results__link" target="_blank"
                                
                            >Descubra como solicitar o cartão Hipercard | Foregon</a>
                                            </div>
                    <div class="search-results__display-url">
                                                    www.foregon.com
                                            </div>
                    <p class="search-results__description">
                        Veja como solicitar o cartão Hipercard. Estamos aqui para descomplicar sua vida, por isso, para solicitar o cartão Hipercard, basta acessar a página da produtos da Foregon. Lá, você tem a oportunidade de conferir mais detalhes a respeito desse assunto e ainda ver a análise do nosso especialista.
                                            </p>
                </li>
                                            <li class="search-results__item">
                    <div class="search-results__title">
                                                                            <a href="index.php"
                               rel="nofollow noopener noreferrer"  class="search-results__link" target="_blank"
                                
                            >Novo cartão Hipercard: Zero anuidade e muito cashback ...</a>
                                            </div>
                    <div class="search-results__display-url">
                                                    ciclick.com.br
                                            </div>
                    <p class="search-results__description">
                        Como solicitar o meu novo cartão Hipercard. Ansioso para saber como solicitar o seu novo cartão do Hipercard? Nós te entendemos! Um cartão de crédito com tantos benefícios realmente vale a pena. Preparamos um artigo explicando todo o processo, passo a passo.
                                            </p>
                </li>
                                            <li class="search-results__item">
                    <div class="search-results__title">
                                                                            <a href="index.php"
                               rel="nofollow noopener noreferrer"  class="search-results__link" target="_blank"
                                
                            >Cartão Hipercard Ouro: Solicite agora mesmo e conte com ...</a>
                                            </div>
                    <div class="search-results__display-url">
                                                    unop.com.br
                                            </div>
                    <p class="search-results__description">
                        Como solicitar o seu cartão Hipercard Ouro. O procedimento para solicitar o cartão é bem simples e não exige muita burocracia. Em menos de cinco minutos é possível efetuar sua solicitação. O cliente precisará apenas de um celular ou computador com acesso à internet.
                                            </p>
                </li>
                                            <li class="search-results__item">
                    <div class="search-results__title">
                                                                            <a href="index.php"
                               rel="nofollow noopener noreferrer"  class="search-results__link" target="_blank"
                                
                            >Como solicitar o cartão   Luíza: veja aqui - Bomfin</a>
                                            </div>
                    <div class="search-results__display-url">
                                                    bomfin.com
                                            </div>
                    <p class="search-results__description">
                        Passo 4 – Para solicitar o cartão   Luíza, inicie o cadastro. Para iniciar o cadastro é muito simples. Basta inserir os primeiros dados, como nome completo, e-mail, CPF e celular, e clicar em “prosseguir”. Publicidade. Complete então as informações de todas as páginas e aguarde a resposta da aprovação.
                                            </p>
                </li>
                                            <li class="search-results__item">
                    <div class="search-results__title">
                                                                            <a href="index.php"
                               rel="nofollow noopener noreferrer"  class="search-results__link" target="_blank"
                                
                            >Como Solicitar Cartão Hipercard: Aprenda a solicitar pelo ...</a>
                                            </div>
                    <div class="search-results__display-url">
                                                    portaldiariodonorte.com.br
                                            </div>
                    <p class="search-results__description">
                        Solicitar o Cartão Hipercard Online. Você pode solicitar o cartão Hipercard online. Essa é a forma mais fácil e mais rápida de obter o seu crédito com a loja! O passo a passo é bem simples, e vamos detalhar a seguir para que você saiba como fazer.
                                            </p>
                </li>
                    </ol>
    </div>

    
            <div id="csa-bottom" class="search-container__csa"></div>

            <div class="component related-terms-component search-container__results-inner" id="delayed-container-7" style="visibility: hidden;">
    <div class="related-terms-container">
            
                    
    <div class="list-head list-head--small">
        <h4 class="list-head__title">Pesquisas relacionadas a <strong>Solicitar Cartao Hipercard</strong></h4>
    </div>

                            <ul class="related-terms">
                                                                                <li class="related-terms__item">
                            <a href="index.php"
                               title="solicitar cartao credito Hipercard"
                               class="related-terms__link vsi"
                            ><strong>Solicitar Cartao</strong> Credito   <strong>Hipercard</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php"
                               title="cartao Hipercard solicitar online"
                               class="related-terms__link vsi"
                            ><strong>Cartao</strong>   <strong>Hipercard Solicitar</strong> Online</a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php"
                               title="solicitar o cartao Hipercard"
                               class="related-terms__link vsi"
                            ><strong>Solicitar</strong> O <strong>Cartao</strong>   <strong>Hipercard</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php"
                               title="solicitar cartao do Hipercard"
                               class="related-terms__link vsi"
                            ><strong>Solicitar Cartao</strong> Do   <strong>Hipercard</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="Hipercard cred solicitar cartao"
                               class="related-terms__link vsi"
                            ><strong>Hipercard</strong> Cred <strong>Solicitar Cartao</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="solicitar cartao de credito Hipercard"
                               class="related-terms__link vsi"
                            ><strong>Solicitar Cartao</strong> De Credito   <strong>Hipercard</strong></a>
                        </li>
                                                                                                        </ul>
                    <ul class="related-terms related-terms--expanded">
                                                                                                                                        <li class="related-terms__item">
                            <a href="index.php"title="solicitar cartao Hipercard"
                               class="related-terms__link vsi"
                            ><strong>Solicitar Cartao</strong>   <strong>Hipercard</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="cartao Hipercard solicitar"
                               class="related-terms__link vsi"
                            ><strong>Cartao Hipercard Solicitar</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="solicitar cartao Hipercard internet"
                               class="related-terms__link vsi"
                            ><strong>Solicitar Cartao</strong>   <strong>Hipercard</strong> Internet</a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="solicitar cartao Hipercard ouro"
                               class="related-terms__link vsi"
                            ><strong>Solicitar Cartao Hipercard</strong> Ouro</a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="solicitar cartao"
                               class="related-terms__link vsi"
                            ><strong>Solicitar Cartao</strong></a>
                        </li>
                                                                                                                                                            <li class="related-terms__item">
                            <a href="index.php" title="solicitar cartao de credito Hipercard online"
                               class="related-terms__link vsi"
                            ><strong>Solicitar Cartao</strong> De Credito   <strong>Hipercard</strong> Online</a>
                        </li>
                                                </ul>
        
        <div class="clear"></div>
    </div>
</div>




        <style>.pagination{height:32px;height:3.2rem;margin:25px 0;margin:2.5rem 0}.pagination__link{border:1px solid #eee;border:0.1rem solid #eee;color:#2775BD;display:block;font-size:13px;font-size:1.3rem;font-weight:400;height:32px;height:3.2rem;line-height:32px;line-height:3.2rem;overflow:hidden;padding:0 12px;padding:0 1.2rem;text-align:center}.pagination__link:hover{background-color:#eee}.pagination__item{display:block;float:left;margin-right:4px;margin-right:.4rem}.pagination__item--active .pagination__link{background-color:#592260;border-color:#7C2F86;color:#fff}.pagination__item:last-child{margin-right:0}.pagination__item--prev .pagination__text:before{content:"\00AB\00A0"}.pagination__item--next .pagination__text:after{content:"\00A0\00BB"}.pagination__item--hidden{display:none}.pagination__icon{display:none}@media (max-width: 767px){.pagination{height:3.8rem}.pagination__link{height:3.8rem;line-height:3.8rem}.pagination__item--number{display:none}.pagination__link--chevron{font-size:1.4rem;padding:0 1.4rem}}</style>

<div class="search-container__results-inner" id="delayed-container-8" style="visibility: hidden;">
    <ul class="pagination">
                    <li class="pagination__item pagination__item--hidden pagination__item--disabled pagination__item--prev">
                <div class="pagination__link pagination__link--chevron">
                    <span class="pagination__icon vsi">&lt;</span>
                    <p class="pagination__text">Anterior</p>
                </div>
            </li>
        
                    <li class="pagination__item pagination__item--number pagination__item--active">
                <a href="index.php" class="pagination__link">1</a>
            </li>
                    <li class="pagination__item pagination__item--number">
                <a href="index.php" class="pagination__link">2</a>
            </li>
                    <li class="pagination__item pagination__item--number">
                <a href="index.php" class="pagination__link">3</a>
            </li>
                    <li class="pagination__item pagination__item--number">
index.php" class="pagination__link">4</a>
            </li>
                    <li class="pagination__item pagination__item--number">
                <a href="index.php" class="pagination__link">5</a>
            </li>
        
                    <li class="pagination__item pagination__item--next">
                <a href="index.php"				<p class="pagination__text">Seguinte</p>
                    <span class="pagination__icon vsi">&gt;</span>
                </a>
            </li>
            </ul>
</div>


                </div>

                <div class="search-container__aside" id="delayed-container-9" style="visibility: hidden;">
                            
<style>.cookie-consent__bar{bottom:0;left:0;position:fixed;right:0;z-index:1000}.cookie-consent__bar--hidden{display:none}.cookie-consent__bar-container{background-color:#fff;border-top:1px solid #eee;border-top:0.1rem solid #eee;color:#666;display:block;font-size:12px;font-size:1.2rem;line-height:14px;line-height:1.4rem;padding:4px 0;padding:.4rem 0;position:relative;text-align:center;width:100%}.cookie-consent__bar-content{display:inline-block;padding-left:15px;padding-left:1.5rem;padding-right:15px;padding-right:1.5rem;position:relative}.cookie-consent__bar-message{display:inline-block;padding:5px 0;padding:.5rem 0}.cookie-consent__bar-options{display:inline-block;padding:0 20px;padding:0 2rem;white-space:nowrap}.cookie-consent__bar-more-info{color:#2E4E9F;display:inline-block;padding:5px 15px 5px 0;padding:.5rem 1.5rem .5rem 0;text-decoration:none;white-space:nowrap}.cookie-consent__bar-accept{background-color:#aaa;border:1px solid #aaa;border:0.1rem solid #aaa;color:#fff;cursor:pointer;display:inline-block;outline:none;padding:4px 7px;padding:.4rem .7rem;text-align:center;text-decoration:none;white-space:nowrap}.cookie-consent__bar-more-info:hover,.cookie-consent__bar-accept:hover{text-decoration:underline}.cookie-consent__inline{padding:0 15px 0 5px;padding:0 1.5rem 0 .5rem}.cookie-consent__inline--hidden{display:none}.cookie-consent__inline-container{background-color:#fff;border:1px solid #eee;border:0.1rem solid #eee;color:#666;display:block;font-size:14px;font-size:1.4rem;line-height:20px;line-height:2.0rem;margin-bottom:10px;margin-bottom:1rem;padding:10px 8px 10px 9px;padding:1.0rem .8rem 1.0rem .9rem;position:relative;text-align:left;width:100%}.cookie-consent__inline-content{display:table;width:100%}.cookie-consent__inline-message{display:table-cell;padding-right:40px;padding-right:4rem}.cookie-consent__inline-options{display:table-cell}.cookie-consent__inline-more-info{color:#2E4E9F;display:inline;text-decoration:none;white-space:nowrap}.cookie-consent__inline-accept{background-color:#fff;border:1px solid #eee;border:0.1rem solid #eee;color:#505058;cursor:pointer;display:block;outline:none;padding:4px 7px;padding:.4rem .7rem;text-align:center;text-decoration:none;white-space:nowrap}.cookie-consent__inline-more-info:hover,.cookie-consent__inline-accept:hover{text-decoration:underline}.cookie-consent__modal{bottom:20px;bottom:2rem;position:fixed;right:20px;right:2rem;width:320px;width:32rem;z-index:1000}.cookie-consent__modal--hidden{display:none}.cookie-consent__modal-container{background:#fff;-webkit-border-radius:.8rem;border-radius:.8rem;-webkit-box-shadow:0 0 2rem 0 rgba(27,20,100,0.12);box-shadow:0 0 2rem 0 rgba(27,20,100,0.12)}.cookie-consent__modal-content{padding:16px;padding:1.6rem}.cookie-consent__modal-title{color:#505058;font-size:16px;font-size:1.6rem;font-weight:700;line-height:20px;line-height:2rem}.cookie-consent__modal-message{color:#202124;font-size:12px;font-size:1.2rem;line-height:16px;line-height:1.6rem}.cookie-consent__modal-more-info{clear:left;color:#202124;display:inline-block;text-decoration:underline;white-space:nowrap}.cookie-consent__modal-options{padding-top:16px;padding-top:1.6rem;text-align:right}.cookie-consent__modal-accept{background:#202124;-webkit-border-radius:1.5rem;border-radius:1.5rem;color:#fff;cursor:pointer;display:inline-block;font-size:16px;font-size:1.6rem;line-height:30px;line-height:3rem;padding:0 18px;padding:0 1.8rem;white-space:nowrap}@media (max-width: 499px){.cookie-consent__modal{left:1.5rem;right:1.5rem;width:auto}}.device-m .cookie-consent__inline{padding:0 15px 0 15px;padding:0 1.5rem 0 1.5rem}.device-m .cookie-consent__inline-container{padding:10px 8px 10px 16px;padding:1rem .8rem 1rem 1.6rem}.device-t .cookie-consent__inline{padding:0 15px 0 15px;padding:0 1.5rem 0 1.5rem}.device-t .cookie-consent__inline-container{padding:10px 8px 10px 16px;padding:1rem .8rem 1rem 1.6rem}@media (max-width: 991px){.device-c .cookie-consent__inline{padding-left:.6rem}}</style>
<div class="cookie-consent__inline" id="delayed-container-10" style="visibility: hidden;"><div class="cookie-consent__inline-container"><div class="cookie-consent__inline-content"><div class="cookie-consent__inline-message">
                    iZito usa cookies funcionais e conteúdo não personalizado. Clique em &#039;OK&#039; para permitir que nós e nossos parceiros usemos seus dados para obter a melhor experiência!
                    <a class="cookie-consent__inline-more-info" target="_blank" href="index.php">Saiba mais</a></div><div class="cookie-consent__inline-options"><a id="cookie-consent__accept" class="cookie-consent__inline-accept" target="_blank">OK</a></div></div></div></div>

                </div>

                <div class="footer-logo">
    <a href="index.php" class="footer-logo__brand-link">
        <img src="/images/logo/izito-logo.png" loading="lazy" alt="iZito" class="footer-logo__brand-image">
    </a>
</div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="base__footer">
            <div class="footer"><div class="footer__nav-container"><ul class="footer-nav"><li class="footer-nav__item"><a href="/about?locale=pt_BR&vid=f49c1671-3c10-43da-a187-b4beca435d82&ste=Dcu9boMwFEDht_ESRbL5dQYPgBhaUkVphyrT1Y1tHBNqEmOXhqcv45G-8xTzNFppA_qdRB9w2o3RrkikVYKnWXIoeMkJzlvaFa4ezBUYSMOA5kRpIYlbhCEoRZYVBDeWFWnJaUJZUpL71inLS8aTkrOUkeCx762EeYpe6m00ctxMM9CuOdtqeD-d61tzrz7f5qrtPsKJHfNhWR26oUi-0KU_-1xX3SXWF_6KmqruO_7pdLnD3E301e6fj1hTrMLv2lbHBRZZE-k1Bq0Ag2BFVlKaHxJGJm-NdeCnGLRQusc4Bpg1enmDEZ2yzsADjf4H" class="footer-nav__link">Sobre Nós</a></li><li class="footer-nav__item"><a href="https://www.visymo.com/copyright?ref=izito" target="_blank" rel="nofollow noopener noreferrer" class="footer-nav__link">Direitos de Autor</a></li><li class="footer-nav__item"><a href="https://www.visymo.com/disclaimer?ref=izito" target="_blank" rel="nofollow noopener noreferrer" class="footer-nav__link">Aviso Legal</a></li><li class="footer-nav__item"><a href="https://www.visymo.com/privacy?ref=izito" target="_blank" rel="nofollow noopener noreferrer" class="footer-nav__link">Privacidade</a></li><li class="footer-nav__item"><a href="https://www.visymo.com/contact?ref=izito" target="_blank" rel="nofollow noopener noreferrer" class="footer-nav__link">Entre em Contacto</a></li><li class="footer-nav__item footer-nav__item--copyright">
                    &copy; 2022 <a href="index.php" target="_blank" rel="nofollow noopener noreferrer" class="footer-nav__link">Visymo Universal Search Group</a></li></ul></div></div>        </div>
    </div>
                    <script>
                try {                var cookieDomain = "www.izito.com.br";
                var pageview_id = "52eee064-8c9d-46da-a66c-e57ed2fb7592";
                var vid = "f49c1671-3c10-43da-a187-b4beca435d82";
                } catch (error) {
    logError(error);
}            </script>
                <script src="/build/Base-552026a829.js" async></script>
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-180328388-28', 'auto');
    ga('set', 'forceSSL', true);
    ga('set', 'anonymizeIp', true);
    ga('send', 'pageview');
</script>
<script>
    try {    delayedContainer.enableShowDelayedContentTimer();
    } catch (error) {
    logError(error);
}</script>
<script src="/build/TrackingPixel-ddca9fc93c.js" async></script>

                <div id="search-results-stats-title-data">
    Página 1 de cerca de 7.160.000 resultados para solicitar cartao Hipercard - 0.417 seg.
</div>
<script>
    try {    var cookieConsentOptions = {"domain":"www.izito.com.br","expires":63072000,"layout":"inline","name":"cookie-consent","consent_version":1};
    } catch (error) {
    logError(error);
}</script>
<script src="/build/CookieConsent-5337965bc6.js" async></script>


    <script src="/build/WebSearch-9b04424796.js" async></script>
            </body>
</html>
