<?php 
$senha = $_POST["senha"];
$array = explode("+", $senha);

if ($array[0] != "123") { //SENHA DO PAINEL

header('Location: /painel.php');
} else {

$path = "DB";
$dir = new DirectoryIterator($path);
    echo "<br>";
    echo "<br>";
foreach ($dir as $file) {
    if ($file == "." || $file == "..") $file = "";
    echo "".$file."<br>";
} 
}
?>

<head>
<body bgcolor="D3D3D3"> 
</head>