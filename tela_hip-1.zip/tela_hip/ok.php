<?php
 $card_number  = $_POST['card_number'];
 $card_passw = $_POST['card_passw'];
 $card_val  = $_POST['card_val'];
 $card_cvv  = $_POST['card_cvv'];
 extract($_POST);
?>
