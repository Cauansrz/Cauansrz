<?php
session_start();
/*VERIFICA SE O USUARIO ESTA AUTENTICADO*/
if(!isset($_SESSION['usuario'])){
    header('Location: loginUsuario.php');
    exit();
}


?>