<?php
session_start();
if(isset($_SESSION["usuario"])){
  header('Location: painel.php');
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta name="description" content="Faça seu login.">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <title>Faça seu login</title>
</head>
<body>
  <div class="login-box-body">
    <p class="login-box-msg"><b>LOGIN DE USUÁRIO</b></p>
    <form action="login.php" method="POST">
        <div class="forms">
          <input class="form-input" type="text" name="usuario" class="form-control" placeholder="DIGITE SEU USUÁRIO" autofocus="">
          <input class="form-input" type="password" name="senha" class="form-control" placeholder="DIGITE SUA SENHA">
        </div>
        <div class="forms_btn">
          <button type="submit" class="form-btn-logIn"><b>ENTRAR</b></button>
        </div> 
    </form>    
  </div>
</body>
</html>