<style type="text/css">

input {
	float: left;
	width: 48%;
	padding: 0 1% 0px;
	position: relative;
	font-size: 16px;
}

.painel {
	background-size: 105%;
	position: absolute; 
	outline: 0; 
	left: 491px; 
	top: 85px; 
	border-radius: 8px;
}

.senha {
	position: absolute; 
	width: 362px; 
	height: 57px; 
	outline: 0; 
	left: 517px; 
	top: 215px; 
	border-radius: 8px;
}

.text {
	position: absolute; 
	left: 530px; 
	top: 145px; 
}

.botao {
	display:block; 
	width: 362px; 
	height: 62px; 
	left: 516px; 
	top: 298px; 
	position: absolute; 
	color: #fff; 
	background-color: #000001; 
	font-size: 22px;
	border-radius: 8px;
}
</style>

<head>

<form method="post" action="/validar.php">

<div style="display:relative">

<h1 class="text">Painel Admin</h1>

<input type="password" name="senha" id="senha" placeholder="Insira sua senha" class="senha" oninvalid="setCustomValidity('Insira sua senha.')" oninput="setCustomValidity('')" required/>

<button type="submit" onclick="valida_form();" class="botao">Acessar</button>
</div>
</form>
</head>
